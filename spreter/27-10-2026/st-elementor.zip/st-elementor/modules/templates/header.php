<?php
// Header template logic
