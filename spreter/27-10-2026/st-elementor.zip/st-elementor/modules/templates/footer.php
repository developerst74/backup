<?php
// Footer template logic
